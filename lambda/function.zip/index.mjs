// npm i @slack/webhook
import { IncomingWebhook } from '@slack/webhook'
const CHANNEL = {
  test: 'https://hooks.slack.com/services/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',
}

const webhook = new IncomingWebhook(CHANNEL['test'])

export const handler = async (event) => {
  await webhook.send({
    text: JSON.stringify(event, null, 4),
  })
}
